package com.animation;

import com.reaper.Menu;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
}

